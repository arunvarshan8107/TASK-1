#!/bin/bash
# ============================================================
#  Upload NSS Report to Google Cloud Storage
#  Usage: bash upload_nss_report.sh YOUR_BUCKET_NAME
# ============================================================

BUCKET="${1:-YOUR_BUCKET_NAME}"
FILE="NSS_REPORT_ARUN_VARSHAN_25CU0330006_CSE_AIML.docx"
GCS_PATH="private/${FILE}"

if [[ "$BUCKET" == "YOUR_BUCKET_NAME" ]]; then
  echo "Usage: bash upload_nss_report.sh YOUR_BUCKET_NAME"
  exit 1
fi

echo "Uploading ${FILE} → gs://${BUCKET}/${GCS_PATH} ..."

gsutil cp \
  "$(dirname "$0")/../example-files/${FILE}" \
  "gs://${BUCKET}/${GCS_PATH}"

echo ""
echo "✅  Upload complete!"
echo ""
echo "  Object : gs://${BUCKET}/${GCS_PATH}"
echo "  Access : Authenticated users only (private/)"
echo ""
echo "  To verify:"
echo "    gsutil ls -l gs://${BUCKET}/private/"
echo ""
echo "  To generate a 1-hour signed URL:"
echo "    gsutil signurl -d 1h YOUR_SA_KEY.json gs://${BUCKET}/${GCS_PATH}"
echo ""
echo "  To make it readable by gcs-reader service account:"
echo "    (already set — see IAM configuration)"
