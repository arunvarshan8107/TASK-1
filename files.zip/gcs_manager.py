"""
gcs_manager.py — Python helper for Google Cloud Storage operations
Requires: pip install google-cloud-storage
Usage:    python gcs_manager.py --project my-project --bucket my-bucket
"""

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path

from google.cloud import storage
from google.cloud.storage import Blob, Bucket, Client
from google.oauth2 import service_account


# ── Client factory ────────────────────────────────────────────
def get_client(key_file: str | None = None) -> Client:
    """Return an authenticated GCS client.

    Priority:
      1. Explicit key_file path (service account JSON)
      2. GOOGLE_APPLICATION_CREDENTIALS env var
      3. Application Default Credentials (gcloud auth application-default login)
    """
    if key_file:
        creds = service_account.Credentials.from_service_account_file(key_file)
        return storage.Client(credentials=creds)
    return storage.Client()  # falls back to ADC


# ── Bucket helpers ────────────────────────────────────────────
def create_bucket(
    client: Client,
    bucket_name: str,
    project: str,
    region: str = "us-central1",
    storage_class: str = "STANDARD",
) -> Bucket:
    """Create a bucket with versioning enabled."""
    bucket: Bucket = client.bucket(bucket_name)
    bucket.storage_class = storage_class

    new_bucket = client.create_bucket(bucket, project=project, location=region)
    new_bucket.versioning_enabled = True
    new_bucket.patch()

    print(f"[OK] Bucket created: gs://{new_bucket.name}  ({region}, {storage_class})")
    return new_bucket


def set_lifecycle(bucket: Bucket) -> None:
    """Apply lifecycle rules (delete old versions, tier backups)."""
    rules = [
        # Delete archived versions when 3+ newer exist
        storage.lifecycle.DeleteRule(
            conditions={"numNewerVersions": 3, "isLive": False}
        ),
        # Delete log files after 90 days
        storage.lifecycle.DeleteRule(
            conditions={"age": 90, "matchesPrefix": ["logs/"]}
        ),
        # Move backups to Nearline after 30 days
        storage.lifecycle.SetStorageClassRule(
            storage_class="NEARLINE",
            conditions={"age": 30, "matchesPrefix": ["backups/"]},
        ),
    ]
    bucket.lifecycle_rules = rules
    bucket.patch()
    print("[OK] Lifecycle rules applied.")


def set_cors(bucket: Bucket) -> None:
    """Configure CORS for web client uploads."""
    bucket.cors = [
        {
            "origin": ["*"],  # Restrict in production
            "method": ["GET", "HEAD", "PUT", "POST", "DELETE"],
            "responseHeader": ["Content-Type", "Authorization", "Content-Length"],
            "maxAgeSeconds": 3600,
        }
    ]
    bucket.patch()
    print("[OK] CORS configured.")


def configure_iam(bucket: Bucket, bindings: dict[str, list[str]]) -> None:
    """Set IAM bindings on the bucket.

    bindings = {
        "roles/storage.admin":        ["serviceAccount:admin@proj.iam..."],
        "roles/storage.objectViewer": ["serviceAccount:reader@proj.iam..."],
        "roles/storage.objectAdmin":  ["serviceAccount:writer@proj.iam..."],
    }
    """
    policy = bucket.get_iam_policy(requested_policy_version=3)
    for role, members in bindings.items():
        policy.bindings.append({"role": role, "members": set(members)})
    bucket.set_iam_policy(policy)
    print(f"[OK] IAM bindings applied: {list(bindings.keys())}")


# ── Upload helpers ────────────────────────────────────────────
def upload_file(
    bucket: Bucket,
    local_path: str | Path,
    gcs_path: str,
    content_type: str | None = None,
) -> Blob:
    blob: Blob = bucket.blob(gcs_path)
    blob.upload_from_filename(str(local_path), content_type=content_type)
    print(f"[UP] {local_path}  →  gs://{bucket.name}/{gcs_path}")
    return blob


def upload_string(
    bucket: Bucket,
    content: str,
    gcs_path: str,
    content_type: str = "text/plain",
) -> Blob:
    blob: Blob = bucket.blob(gcs_path)
    blob.upload_from_string(content, content_type=content_type)
    print(f"[UP] (string) →  gs://{bucket.name}/{gcs_path}")
    return blob


def create_folder_structure(bucket: Bucket) -> None:
    """Create placeholder objects that act as folder markers."""
    for folder in ("public", "private", "uploads", "backups", "logs"):
        upload_string(bucket, "", f"{folder}/.keep", content_type="text/plain")
    print("[OK] Folder structure created.")


def upload_example_files(bucket: Bucket) -> None:
    """Upload a set of example files across different folders."""
    ts = datetime.now(timezone.utc).isoformat()

    upload_string(
        bucket,
        f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>GCS Demo</title></head>
<body>
  <h1>Hello from Google Cloud Storage 🚀</h1>
  <p>Bucket: <strong>{bucket.name}</strong></p>
  <p>Generated: {ts}</p>
</body></html>""",
        "public/index.html",
        content_type="text/html",
    )

    upload_string(
        bucket,
        json.dumps(
            {
                "service": "Google Cloud Storage",
                "bucket": bucket.name,
                "status": "active",
                "created": ts,
            },
            indent=2,
        ),
        "public/sample.json",
        content_type="application/json",
    )

    upload_string(
        bucket,
        f"# Private config\nbucket: {bucket.name}\ncreated: {ts}\n",
        "private/config.yaml",
        content_type="text/yaml",
    )

    upload_string(
        bucket,
        "timestamp,file,size_bytes\n"
        f"{ts},config.yaml,128\n"
        f"{ts},index.html,256\n",
        "backups/manifest.csv",
        content_type="text/csv",
    )

    upload_string(
        bucket,
        "=== Uploads ===\nDrop user content here.\nNot publicly accessible.\n",
        "uploads/README.txt",
    )

    print("[OK] Example files uploaded.")


# ── Download / list helpers ───────────────────────────────────
def list_objects(bucket: Bucket, prefix: str = "") -> None:
    blobs = list(bucket.list_blobs(prefix=prefix))
    print(f"\n{'NAME':<55} {'SIZE':>10}  {'UPDATED'}")
    print("─" * 90)
    for b in blobs:
        size = f"{b.size or 0:,}"
        updated = b.updated.strftime("%Y-%m-%d %H:%M") if b.updated else "—"
        print(f"  {b.name:<53} {size:>10}  {updated}")
    print(f"\n  Total: {len(blobs)} objects\n")


def generate_signed_url(blob: Blob, expiry_minutes: int = 60) -> str:
    from datetime import timedelta
    url = blob.generate_signed_url(expiration=timedelta(minutes=expiry_minutes), version="v4")
    print(f"[URL] Valid for {expiry_minutes} min: {url}")
    return url


# ── CLI ───────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="GCS bucket manager")
    parser.add_argument("--project", required=True, help="GCP project ID")
    parser.add_argument("--bucket",  required=True, help="Bucket name")
    parser.add_argument("--region",  default="us-central1")
    parser.add_argument("--key",     default=None, help="Path to service account JSON key")
    parser.add_argument("--list",    action="store_true", help="List bucket contents")
    parser.add_argument("--create",  action="store_true", help="Create & configure bucket")
    args = parser.parse_args()

    client = get_client(args.key)

    if args.create:
        bucket = create_bucket(client, args.bucket, args.project, args.region)
        set_lifecycle(bucket)
        set_cors(bucket)
        create_folder_structure(bucket)
        upload_example_files(bucket)
        print(f"\n✅  Setup complete: gs://{args.bucket}")
    else:
        bucket = client.get_bucket(args.bucket)

    if args.list:
        list_objects(bucket)


if __name__ == "__main__":
    main()
