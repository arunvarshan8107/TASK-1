# ============================================================
#  Terraform — Google Cloud Storage bucket + IAM
#  Usage:
#    terraform init
#    terraform apply -var="project_id=YOUR_PROJECT" -var="bucket_name=YOUR_BUCKET"
# ============================================================

terraform {
  required_version = ">= 1.5"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}

# ── Variables ─────────────────────────────────────────────────
variable "project_id" {
  description = "GCP project ID"
  type        = string
}

variable "bucket_name" {
  description = "Globally unique bucket name"
  type        = string
}

variable "region" {
  description = "GCS bucket region"
  type        = string
  default     = "us-central1"
}

variable "storage_class" {
  description = "Storage class: STANDARD | NEARLINE | COLDLINE | ARCHIVE"
  type        = string
  default     = "STANDARD"
}

variable "admin_members" {
  description = "Members to grant storage.admin"
  type        = list(string)
  default     = []
}

variable "reader_members" {
  description = "Members to grant storage.objectViewer"
  type        = list(string)
  default     = []
}

variable "writer_members" {
  description = "Members to grant storage.objectAdmin"
  type        = list(string)
  default     = []
}

# ── Provider ──────────────────────────────────────────────────
provider "google" {
  project = var.project_id
  region  = var.region
}

# ── Enable APIs ───────────────────────────────────────────────
resource "google_project_service" "storage" {
  service            = "storage.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "iam" {
  service            = "iam.googleapis.com"
  disable_on_destroy = false
}

# ── Logging bucket ────────────────────────────────────────────
resource "google_storage_bucket" "log_bucket" {
  name                        = "${var.bucket_name}-logs"
  location                    = var.region
  storage_class               = "NEARLINE"
  uniform_bucket_level_access = true
  force_destroy               = false

  lifecycle_rule {
    action { type = "Delete" }
    condition { age = 90 }
  }
}

# ── Main bucket ───────────────────────────────────────────────
resource "google_storage_bucket" "main" {
  name                        = var.bucket_name
  location                    = var.region
  storage_class               = var.storage_class
  uniform_bucket_level_access = true   # Recommended: disables per-object ACLs
  force_destroy               = false

  # Versioning
  versioning {
    enabled = true
  }

  # Lifecycle rules
  lifecycle_rule {
    action { type = "Delete" }
    condition {
      num_newer_versions = 3
      with_state         = "ARCHIVED"
    }
  }

  lifecycle_rule {
    action {
      type          = "SetStorageClass"
      storage_class = "NEARLINE"
    }
    condition {
      age            = 30
      matches_prefix = ["backups/"]
    }
  }

  lifecycle_rule {
    action { type = "Delete" }
    condition {
      age            = 90
      matches_prefix = ["logs/"]
    }
  }

  # Access logging
  logging {
    log_bucket        = google_storage_bucket.log_bucket.name
    log_object_prefix = "access-logs/"
  }

  # CORS for web clients
  cors {
    origin          = ["*"]   # Restrict in production
    method          = ["GET", "HEAD", "PUT", "POST", "DELETE"]
    response_header = ["Content-Type", "Authorization", "Content-Length"]
    max_age_seconds = 3600
  }

  # Soft-delete (30 days)
  soft_delete_policy {
    retention_duration_seconds = 2592000
  }

  depends_on = [google_project_service.storage]
}

# ── Service accounts ──────────────────────────────────────────
resource "google_service_account" "gcs_admin" {
  account_id   = "gcs-admin"
  display_name = "GCS Admin"
  description  = "Full control over the GCS bucket"
}

resource "google_service_account" "gcs_reader" {
  account_id   = "gcs-reader"
  display_name = "GCS Reader"
  description  = "Read-only access to GCS objects"
}

resource "google_service_account" "gcs_writer" {
  account_id   = "gcs-writer"
  display_name = "GCS Writer"
  description  = "Read/write access to GCS objects"
}

# ── Bucket-level IAM ─────────────────────────────────────────
resource "google_storage_bucket_iam_binding" "admins" {
  bucket = google_storage_bucket.main.name
  role   = "roles/storage.admin"
  members = concat(
    ["serviceAccount:${google_service_account.gcs_admin.email}"],
    var.admin_members
  )
}

resource "google_storage_bucket_iam_binding" "readers" {
  bucket = google_storage_bucket.main.name
  role   = "roles/storage.objectViewer"
  members = concat(
    ["serviceAccount:${google_service_account.gcs_reader.email}"],
    var.reader_members
  )
}

resource "google_storage_bucket_iam_binding" "writers" {
  bucket = google_storage_bucket.main.name
  role   = "roles/storage.objectAdmin"
  members = concat(
    ["serviceAccount:${google_service_account.gcs_writer.email}"],
    var.writer_members
  )
}

# ── SA keys (store securely!) ────────────────────────────────
resource "google_service_account_key" "reader_key" {
  service_account_id = google_service_account.gcs_reader.name
}

resource "google_service_account_key" "writer_key" {
  service_account_id = google_service_account.gcs_writer.name
}

# ── Placeholder objects (folder markers) ─────────────────────
locals {
  folders = ["public/.keep", "private/.keep", "uploads/.keep", "backups/.keep", "logs/.keep"]
}

resource "google_storage_bucket_object" "folders" {
  for_each = toset(local.folders)
  name     = each.value
  bucket   = google_storage_bucket.main.name
  content  = ""
}

# ── Outputs ───────────────────────────────────────────────────
output "bucket_name" {
  value       = google_storage_bucket.main.name
  description = "GCS bucket name"
}

output "bucket_url" {
  value       = google_storage_bucket.main.url
  description = "gs:// URL"
}

output "bucket_self_link" {
  value       = google_storage_bucket.main.self_link
  description = "Full self-link URL"
}

output "admin_sa_email" {
  value = google_service_account.gcs_admin.email
}

output "reader_sa_email" {
  value = google_service_account.gcs_reader.email
}

output "writer_sa_email" {
  value = google_service_account.gcs_writer.email
}

output "reader_key_base64" {
  value     = google_service_account_key.reader_key.private_key
  sensitive = true
}

output "writer_key_base64" {
  value     = google_service_account_key.writer_key.private_key
  sensitive = true
}
