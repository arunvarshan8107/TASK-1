# Google Cloud Storage — Bucket Setup Package

A complete, production-ready GCS bucket setup with example files, IAM access
control, versioning, lifecycle management, and CORS.

---

## 📁 Package Contents

```
gcs-setup/
├── scripts/
│   ├── setup_gcs.sh        ← Bash one-shot setup script
│   └── gcs_manager.py      ← Python SDK helper library + CLI
├── configs/
│   ├── main.tf             ← Terraform IaC (recommended for teams)
│   └── terraform.tfvars.example
├── example-files/
│   ├── index.html          ← Public HTML file
│   └── sample.json         ← Public JSON data file
└── README.md               ← This file
```

---

## ⚡ Quick Start — Bash Script (fastest)

```bash
# 1. Authenticate
gcloud auth login
gcloud auth application-default login

# 2. Run the setup script
bash scripts/setup_gcs.sh my-project-id my-unique-bucket us-central1
```

That's it. The script will:
- Enable required Google Cloud APIs
- Create the bucket with versioning on
- Build the folder structure
- Apply lifecycle, CORS, and logging rules
- Create 3 service accounts with appropriate roles
- Upload 5 example files
- Generate service-account key files

---

## 🏗️ Infrastructure-as-Code — Terraform (recommended for teams)

```bash
cd configs/
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your project_id and bucket_name

terraform init
terraform plan
terraform apply
```

Retrieve service account keys after apply:

```bash
terraform output -raw reader_key_base64 | base64 -d > gcs-reader-key.json
terraform output -raw writer_key_base64 | base64 -d > gcs-writer-key.json
```

---

## 🐍 Python SDK

```bash
pip install google-cloud-storage

# Create + configure bucket
python scripts/gcs_manager.py \
  --project my-project-id \
  --bucket  my-unique-bucket \
  --region  us-central1 \
  --create

# List contents
python scripts/gcs_manager.py \
  --project my-project-id \
  --bucket  my-unique-bucket \
  --list

# Use a service account key
python scripts/gcs_manager.py \
  --project my-project-id \
  --bucket  my-unique-bucket \
  --key     ./keys/gcs-writer-key.json \
  --list
```

---

## 🗂️ Bucket Structure

| Folder       | Access              | Purpose                          |
|-------------|---------------------|----------------------------------|
| `public/`   | Public (allUsers)   | Static assets, HTML, JSON        |
| `private/`  | Authenticated only  | Config files, secrets            |
| `uploads/`  | Authenticated only  | User-generated content           |
| `backups/`  | Authenticated only  | Auto-tiered to Nearline at 30d   |
| `logs/`     | Authenticated only  | GCS access logs, deleted at 90d  |

---

## 🔐 IAM Roles

| Service Account  | Role                       | Can do                      |
|-----------------|----------------------------|-----------------------------|
| `gcs-admin`     | `roles/storage.admin`      | Full bucket + object control |
| `gcs-writer`    | `roles/storage.objectAdmin`| Upload, update, delete objects |
| `gcs-reader`    | `roles/storage.objectViewer`| List and download objects   |

---

## ⚙️ Features Configured

| Feature          | Setting                                                        |
|-----------------|----------------------------------------------------------------|
| Versioning       | Enabled — keeps full history                                   |
| Lifecycle        | Old versions pruned after 3 newer; logs deleted at 90d        |
| Storage tiering  | Backups moved to NEARLINE after 30 days                        |
| CORS             | Enabled for all origins (restrict in production)               |
| Logging          | Access logs written to `logs/` prefix                          |
| Soft delete      | 30-day recovery window                                         |

---

## 📦 Example Files Uploaded

| GCS Path                      | Access      | Description             |
|------------------------------|-------------|-------------------------|
| `public/index.html`          | Public      | Demo HTML page          |
| `public/sample.json`         | Public      | Bucket metadata JSON    |
| `private/config.yaml`        | Auth only   | App configuration       |
| `uploads/README.txt`         | Auth only   | Folder usage guide      |
| `backups/backup_manifest.csv`| Auth only   | Backup inventory        |

---

## 🌐 Accessing Public Files

After setup, public files are reachable at:

```
https://storage.googleapis.com/YOUR_BUCKET/public/index.html
https://storage.googleapis.com/YOUR_BUCKET/public/sample.json
```

Or via `gsutil`:

```bash
gsutil cp gs://YOUR_BUCKET/public/index.html .
```

---

## 🔑 Signed URLs (for private files)

Generate a time-limited URL without making objects public:

```bash
gsutil signurl -d 1h gcs-reader-key.json gs://YOUR_BUCKET/private/config.yaml
```

Or in Python:

```python
from google.cloud import storage
client = storage.Client()
blob = client.bucket("YOUR_BUCKET").blob("private/config.yaml")
url = blob.generate_signed_url(expiration=3600, version="v4")
print(url)
```

---

## 🔒 Security Checklist

- [ ] Replace `*` CORS origin with your actual domain
- [ ] Rotate service-account keys every 90 days
- [ ] Never commit key files to version control (add `keys/` to `.gitignore`)
- [ ] Enable Cloud Audit Logs for Data Access events
- [ ] Use Workload Identity Federation instead of key files in GKE/Cloud Run
- [ ] Review IAM bindings quarterly with `gsutil iam get gs://YOUR_BUCKET`

---

## 🛠️ Useful Commands

```bash
# List all objects
gsutil ls -la gs://YOUR_BUCKET/

# Check IAM policy
gsutil iam get gs://YOUR_BUCKET

# Check bucket config
gsutil versioning get gs://YOUR_BUCKET
gsutil lifecycle get gs://YOUR_BUCKET
gsutil cors get gs://YOUR_BUCKET

# Upload a file
gsutil cp myfile.pdf gs://YOUR_BUCKET/uploads/myfile.pdf

# Download a file
gsutil cp gs://YOUR_BUCKET/public/index.html .

# Sync a local directory
gsutil -m rsync -r ./dist gs://YOUR_BUCKET/public/
```
