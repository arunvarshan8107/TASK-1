#!/bin/bash
# ============================================================
#  Google Cloud Storage - Full Bucket Setup Script
#  Usage: bash setup_gcs.sh [PROJECT_ID] [BUCKET_NAME] [REGION]
# ============================================================

set -euo pipefail

# ── Configurable defaults ────────────────────────────────────
PROJECT_ID="${1:-my-gcs-project}"
BUCKET_NAME="${2:-my-app-bucket-$(date +%s)}"
REGION="${3:-us-central1}"
STORAGE_CLASS="STANDARD"    # STANDARD | NEARLINE | COLDLINE | ARCHIVE

# Service accounts
SA_ADMIN="gcs-admin@${PROJECT_ID}.iam.gserviceaccount.com"
SA_READER="gcs-reader@${PROJECT_ID}.iam.gserviceaccount.com"
SA_WRITER="gcs-writer@${PROJECT_ID}.iam.gserviceaccount.com"

# Colours
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── Preflight checks ─────────────────────────────────────────
check_prerequisites() {
  info "Checking prerequisites..."
  command -v gcloud >/dev/null 2>&1 || error "gcloud CLI not found. Install: https://cloud.google.com/sdk"
  command -v gsutil >/dev/null 2>&1 || error "gsutil not found (included with gcloud SDK)."
  gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q . \
    || error "No active gcloud account. Run: gcloud auth login"
  success "All prerequisites met."
}

# ── Project setup ────────────────────────────────────────────
setup_project() {
  info "Setting active project to: ${PROJECT_ID}"
  gcloud config set project "${PROJECT_ID}"

  info "Enabling required APIs..."
  gcloud services enable \
    storage.googleapis.com \
    iam.googleapis.com \
    cloudresourcemanager.googleapis.com \
    --quiet
  success "APIs enabled."
}

# ── Bucket creation ──────────────────────────────────────────
create_bucket() {
  info "Creating bucket: gs://${BUCKET_NAME}"
  if gsutil ls "gs://${BUCKET_NAME}" &>/dev/null; then
    warn "Bucket gs://${BUCKET_NAME} already exists — skipping creation."
  else
    gsutil mb \
      -p "${PROJECT_ID}" \
      -c "${STORAGE_CLASS}" \
      -l "${REGION}" \
      -b on \
      "gs://${BUCKET_NAME}"
    success "Bucket created: gs://${BUCKET_NAME}"
  fi
}

# ── Folder structure ─────────────────────────────────────────
create_folder_structure() {
  info "Creating folder structure..."
  for folder in public/ private/ uploads/ backups/ logs/; do
    echo "" | gsutil cp - "gs://${BUCKET_NAME}/${folder}.keep"
  done
  success "Folder structure created."
}

# ── Bucket-level settings ────────────────────────────────────
configure_bucket() {
  info "Configuring versioning, lifecycle, logging, CORS..."

  # Versioning
  gsutil versioning set on "gs://${BUCKET_NAME}"

  # Lifecycle — delete non-current versions older than 30 days
  gsutil lifecycle set /dev/stdin "gs://${BUCKET_NAME}" <<'JSON'
{
  "rule": [
    {
      "action": {"type": "Delete"},
      "condition": {"numNewerVersions": 3, "isLive": false}
    },
    {
      "action": {"type": "Delete"},
      "condition": {"age": 90, "matchesPrefix": ["logs/"]}
    },
    {
      "action": {"type": "SetStorageClass", "storageClass": "NEARLINE"},
      "condition": {"age": 30, "matchesPrefix": ["backups/"]}
    }
  ]
}
JSON

  # CORS — allow web uploads from any origin (tighten for production)
  gsutil cors set /dev/stdin "gs://${BUCKET_NAME}" <<'JSON'
[
  {
    "origin": ["*"],
    "method": ["GET","HEAD","PUT","POST","DELETE"],
    "responseHeader": ["Content-Type","Authorization","Content-Length","X-Requested-With"],
    "maxAgeSeconds": 3600
  }
]
JSON

  # Logging
  gsutil logging set on -b "gs://${BUCKET_NAME}" -o "logs/" "gs://${BUCKET_NAME}"

  # Retention lock (7-day soft delete)
  gsutil retention set 7d "gs://${BUCKET_NAME}" 2>/dev/null \
    || warn "Retention policy requires additional permissions — skipped."

  success "Bucket configuration applied."
}

# ── Service accounts ─────────────────────────────────────────
create_service_accounts() {
  info "Creating service accounts..."
  for sa_name in gcs-admin gcs-reader gcs-writer; do
    if gcloud iam service-accounts describe "${sa_name}@${PROJECT_ID}.iam.gserviceaccount.com" &>/dev/null; then
      warn "Service account ${sa_name} already exists — skipping."
    else
      gcloud iam service-accounts create "${sa_name}" \
        --display-name="GCS ${sa_name^}" \
        --description="Managed by setup_gcs.sh"
    fi
  done
  success "Service accounts ready."
}

# ── IAM bindings ──────────────────────────────────────────────
configure_iam() {
  info "Configuring IAM permissions..."

  # Admin — full control
  gsutil iam ch "serviceAccount:${SA_ADMIN}:roles/storage.admin" "gs://${BUCKET_NAME}"

  # Writer — upload & manage objects
  gsutil iam ch "serviceAccount:${SA_WRITER}:roles/storage.objectAdmin" "gs://${BUCKET_NAME}"

  # Reader — list + download only
  gsutil iam ch "serviceAccount:${SA_READER}:roles/storage.objectViewer" "gs://${BUCKET_NAME}"

  # Public read on /public prefix only (fine-grained object ACL)
  # Note: enable uniform access OFF or use IAM Conditions for prefix-based rules
  success "IAM bindings applied."
}

# ── Public read on /public folder (object-level ACL) ─────────
configure_public_access() {
  info "Configuring public read access for gs://${BUCKET_NAME}/public/..."
  # Works only if uniform bucket-level access is OFF
  gsutil iam ch allUsers:roles/storage.legacyObjectReader \
    "gs://${BUCKET_NAME}" 2>/dev/null \
    || warn "Public allUsers binding skipped (uniform bucket-level access is ON — use signed URLs instead)."
}

# ── Upload example files ──────────────────────────────────────
upload_example_files() {
  info "Uploading example files..."

  TMP="$(mktemp -d)"

  # --- public/index.html ---
  cat > "${TMP}/index.html" <<'HTML'
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>GCS Demo</title></head>
<body>
  <h1>Hello from Google Cloud Storage 🚀</h1>
  <p>This file is publicly accessible via gs://BUCKET/public/index.html</p>
</body>
</html>
HTML

  # --- public/sample.json ---
  cat > "${TMP}/sample.json" <<'JSON'
{
  "service": "Google Cloud Storage",
  "bucket": "BUCKET_PLACEHOLDER",
  "region": "REGION_PLACEHOLDER",
  "status": "active",
  "created": "2026-06-01"
}
JSON
  sed -i "s/BUCKET_PLACEHOLDER/${BUCKET_NAME}/g; s/REGION_PLACEHOLDER/${REGION}/g" "${TMP}/sample.json"

  # --- private/config.yaml ---
  cat > "${TMP}/config.yaml" <<YAML
# Private configuration — not publicly accessible
project: ${PROJECT_ID}
bucket: ${BUCKET_NAME}
region: ${REGION}
storage_class: ${STORAGE_CLASS}
versioning: enabled
logging: enabled
YAML

  # --- uploads/README.txt ---
  cat > "${TMP}/README.txt" <<TXT
=== Uploads Folder ===
Drop user-generated content here.
Files in this folder are NOT public.
Access requires authenticated service-account credentials.
TXT

  # --- backups/backup_manifest.csv ---
  cat > "${TMP}/backup_manifest.csv" <<CSV
timestamp,file,size_bytes,checksum
2026-06-01T00:00:00Z,config.yaml,312,abc123
2026-06-01T00:00:00Z,index.html,256,def456
CSV

  # Upload
  gsutil cp "${TMP}/index.html"           "gs://${BUCKET_NAME}/public/index.html"
  gsutil cp "${TMP}/sample.json"          "gs://${BUCKET_NAME}/public/sample.json"
  gsutil cp "${TMP}/config.yaml"          "gs://${BUCKET_NAME}/private/config.yaml"
  gsutil cp "${TMP}/README.txt"           "gs://${BUCKET_NAME}/uploads/README.txt"
  gsutil cp "${TMP}/backup_manifest.csv"  "gs://${BUCKET_NAME}/backups/backup_manifest.csv"

  rm -rf "${TMP}"
  success "Example files uploaded."
}

# ── Generate key files for service accounts ───────────────────
generate_keys() {
  info "Generating service-account key files..."
  mkdir -p keys
  for sa_name in gcs-admin gcs-reader gcs-writer; do
    gcloud iam service-accounts keys create \
      "keys/${sa_name}-key.json" \
      --iam-account="${sa_name}@${PROJECT_ID}.iam.gserviceaccount.com"
  done
  warn "Key files saved to ./keys/ — store them securely and never commit to git!"
  success "Keys generated."
}

# ── Summary ───────────────────────────────────────────────────
print_summary() {
  echo ""
  echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
  echo -e "${GREEN}║          GCS Setup Complete ✅                       ║${NC}"
  echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
  echo ""
  echo "  Bucket  : gs://${BUCKET_NAME}"
  echo "  Project : ${PROJECT_ID}"
  echo "  Region  : ${REGION}"
  echo "  Class   : ${STORAGE_CLASS}"
  echo ""
  echo "  Folders:"
  echo "    gs://${BUCKET_NAME}/public/     → Publicly readable files"
  echo "    gs://${BUCKET_NAME}/private/    → Authenticated access only"
  echo "    gs://${BUCKET_NAME}/uploads/    → User-generated content"
  echo "    gs://${BUCKET_NAME}/backups/    → Auto-tiered to Nearline after 30d"
  echo "    gs://${BUCKET_NAME}/logs/       → Access logs (deleted after 90d)"
  echo ""
  echo "  Service Accounts:"
  echo "    ${SA_ADMIN}   → storage.admin"
  echo "    ${SA_WRITER}  → storage.objectAdmin"
  echo "    ${SA_READER}  → storage.objectViewer"
  echo ""
  echo "  Next steps:"
  echo "    gsutil ls gs://${BUCKET_NAME}/"
  echo "    gsutil iam get gs://${BUCKET_NAME}"
  echo ""
}

# ── Main ──────────────────────────────────────────────────────
main() {
  check_prerequisites
  setup_project
  create_bucket
  create_folder_structure
  configure_bucket
  create_service_accounts
  configure_iam
  configure_public_access
  upload_example_files
  generate_keys
  print_summary
}

main "$@"
